import React from "react";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@material-ui/core/IconButton";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import { connect } from "react-redux";
import { store } from "./store";
import axios from "axios";

class Edit extends React.Component {
  constructor() {
    super();
    this.state = {
      form: {
        firstName: "",
        lastName: "",
        emailAddress: "",
        password: ""
      },
      formErrorMessage: {
        firstName: "",
        lastName: "",
        password: ""
      },
      formValid: {
        firstName: false,
        lastName: false,
        password: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: "",
      showPassword: false,
      show:""
    };
  }
  componentWillMount = () => {
    this.fetchDetails();
    console.log("state", this.state);
    const action = {
      type: "Login",
      emailId: localStorage.getItem("email")
        ? localStorage.getItem("email")
        : "",
      firstName: localStorage.getItem("firstName")
        ? localStorage.getItem("firstName")
        : "",
      lastName: localStorage.getItem("lastName")
        ? localStorage.getItem("lastName")
        : "",
      password: localStorage.getItem("password")
        ? localStorage.getItem("password")
        : "",
      customerId: localStorage.getItem("customerId")
        ? localStorage.getItem("customerId")
        : ""
    };
    store.dispatch(action);

    // if(this.state.successMessage){
    //   this.setState({
    //     resultMessage: "Updated"
    //   });
    // }
    // else{
    //   this.setState({
    //     resultMessage: ""
    //   });
    // }
  };

  fetchDetails = () => {
    let obj = this.state;
    localStorage.getItem("email")
      ? (obj.form.emailAddress = this.props.emailId)
      : (obj.form.emailAddress = "");

    localStorage.getItem("firstName")
      ? (obj.form.firstName = this.props.firstName)
      : (obj.form.firstName = "");
    localStorage.getItem("lastName")
      ? (obj.form.lastName = this.props.lastName)
      : (obj.form.lastName = "");
    localStorage.getItem("password")
      ? (obj.form.password = this.props.password)
      : (obj.form.password = "");
    this.setState(obj);
  };

  editUser = () => {
    var editObj = {
      firstName: this.state.form.firstName,
      lastName: this.state.form.lastName,
      email: this.state.form.emailAddress,
      password: this.state.form.password
    };
    var action = {
      type: "Login"
    };
    axios
      .put("http://localhost:2500/edit", editObj)
      .then(response => {
        this.setState({
          successMessage: "Updated successfully",
          errorMessage: "",
          show:"show"
        });

        action.emailId = response.data.message.email;
        action.firstName = response.data.message.firstName;
        action.lastName = response.data.message.lastName;
        action.password = response.data.message.password;
        action.customerId = response.data.message.customerId;

        localStorage.setItem("email", response.data.message.email);
        localStorage.setItem("firstName", response.data.message.firstName);
        localStorage.setItem("lastName", response.data.message.lastName);
        localStorage.setItem("password", response.data.message.password);
        localStorage.setItem("customerId", response.data.message.customerId);
        store.dispatch(action);
      })
      .catch(err => {
        this.setState({
          errorMessage: err.response.data.message,
          successMessage: ""
        });
      });
  };

  handleChange = event => {
    var value = event.target.value;
    var fieldname = event.target.name;
    var form = this.state.form;

    form[fieldname] = value;

    this.setState({ form: form ,successMessage:"",errorMessage:""});
    this.validateField(fieldname, value);
  };

  validateField = (fieldName, value) => {
    var formErrorMessage = this.state.formErrorMessage;
    var formValid = this.state.formValid;

    if (fieldName === "firstName") {
      if (value === "") {
        formErrorMessage.firstName = "field required";
        formValid.firstName = false;
      } else if (value.match(/^[A-Z][a-z]{3,}$/)) {
        formErrorMessage.firstName = "";
        formValid.firstName = true;
      } else {
        formErrorMessage.firstName =
          "First letter should be capital and min 4 char long";
        formValid.firstName = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "lastName") {
      if (value === "") {
        formErrorMessage.lastName = "field required";
        formValid.lastName = false;
      } else if (value.match(/^[A-z]{1,}$/)) {
        formErrorMessage.lastName = "";
        formValid.lastName = true;
      } else {
        formErrorMessage.lastName = "Last name must be there";
        formValid.lastName = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "password") {
      var Cpass = this.state.form.confirmPassword;
      if (value === "") {
        formErrorMessage.password = "field required";
        formValid.password = false;
      } else if (value.length <= 5) {
        formErrorMessage.password = "Password must be 6 character long";
        formValid.password = false;
      } else if (Cpass) {
        if (Cpass === value) {
          formErrorMessage.confirmPassword = "";
          formValid.confirmPassword = true;
        } else {
          formErrorMessage.confirmPassword = "Password dosen't Match";
          formValid.confirmPassword = false;
        }
      } else {
        formErrorMessage.password = "";
        formValid.password = true;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    }
    
    formValid.buttonActive =
      formValid.firstName || formValid.lastName || formValid.password;

    this.setState({ formValid: formValid });
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };

  handleSubmit = event => {
    event.preventDefault();
    this.editUser();
  };

  render() {
    
    return (
      <React.Fragment>  
            
        <button
          type="button"
          class="btn"
          data-toggle="modal"
          data-target="#myModal"
          onClick={()=>this.setState({successMessage:"",errorMessage:""})}
        >
          <span
            className="navbar-brand"
            style={{ color: "white", fontFamily: "arial" }}
          >
            Edit
          </span>
        </button>

        <div className="col-sm-6 d-flex justify-content-center">
          <div id="myModal" class="modal fade" role="dialog">
            <div className="modal-dialog">
              <div className="modal-content">
                <div class="modal-body">
                  <button
                    type="button"
                    class="close"
                    data-dismiss="modal"
                    aria-label="Close"
                    onClick={()=>this.setState({successMessage:"",errorMessage:""})}
                  >
                    <i style={{ color: "black" }} className="fas fa-times" />
                  </button>
                  <br />
                  <React.Fragment>
                    <br />
                    <div className="card" style={{ borderRadius: "20px" }}>
                      <div className="card-header">
                        <h3 className="text-center">
                          <strong>Edit Profile</strong>
                        </h3>
                      </div>
                      <div className="card-body">
                        <form onSubmit={this.handleSubmit}>
                          <div className="form-group row">
                            <label className="col-sm-1">
                              <i
                                className="fas fa-user"
                                style={{ fontSize: "25px" }}
                              />
                            </label>
                            <div className="col-sm-5">
                              <TextField
                                className="form-control"
                                type="text"
                                name="firstName"
                                onChange={this.handleChange}
                                value={this.state.form.firstName}
                              />
                              <span
                                className="text-danger"
                                name="firstNameError"
                              >
                                {this.state.formErrorMessage.firstName}
                              </span>
                            </div>
                            <div className="col-sm-6">
                              <TextField
                                className="form-control"
                                type="text"
                                name="lastName"
                                onChange={this.handleChange}
                                value={this.state.form.lastName}
                              />
                              <span
                                className="text-danger"
                                name="lastNameError"
                              >
                                {this.state.formErrorMessage.lastName}
                              </span>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="col-sm-1">
                              <i
                                class="fas fa-envelope"
                                style={{ fontSize: "25px" }}
                              />
                            </label>
                            <div className="col-sm-11">
                              <TextField
                                className="form-control"
                                type="email"
                                name="emailAddress"
                                value={this.state.form.emailAddress}
                                disabled
                              />

                              <span
                                className="text-danger"
                                name="emailAddressError"
                              >
                                {this.state.formErrorMessage.emailAddress}
                              </span>
                            </div>
                          </div>

                          <div className="form-group row">
                            <label className="col-sm-1">
                              <i
                                class="fas fa-unlock"
                                style={{ fontSize: "25px" }}
                              />
                            </label>
                            <div className="col-sm-11">
                              <TextField
                                id="filled-adornment-password"
                                className="form-control"
                                type={
                                  this.state.showPassword ? "text" : "password"
                                }
                                name="password"
                                onChange={this.handleChange}
                                value={this.state.form.password}
                                InputProps={{
                                  endAdornment: (
                                    <InputAdornment position="end">
                                      <IconButton
                                        aria-label="Toggle password visibility"
                                        onClick={this.handleClickShowPassword}
                                      >
                                        {this.state.showPassword ? (
                                          <VisibilityOff />
                                        ) : (
                                          <Visibility />
                                        )}
                                      </IconButton>
                                    </InputAdornment>
                                  )
                                }}
                              />
                              <span
                                className="text-danger"
                                name="passwordError"
                              >
                                {this.state.formErrorMessage.password}
                              </span>
                            </div>
                          </div>

                          <button
                            type="submit"
                            className="btn form-control"
                            disabled={!this.state.formValid.buttonActive}
                            style={{ backgroundColor: "#F3E367" }}
                            name="lprs"
                          >
                            <strong>Submit</strong>
                          </button>
                                 
                          <span className="text-success" name="successmessage">
                           <strong><center> {this.state.successMessage}</center></strong>
                          </span>
                          <span className="text-danger" name="errorMessage">
                            {this.state.errorMessage}
                          </span>
                          <br />
                        </form>
                      </div>
                    </div>
                  </React.Fragment>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
Edit = connect(mapStateToProps)(Edit);
export default Edit;
