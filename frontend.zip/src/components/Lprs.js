import React, { Component } from "react";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";

class Lprs extends Component {
  constructor() {
    super();
    this.state = {
      msg: ""
    };
  }

  handleClick = () => {
    if (this.props.emailId) {
      this.setState({ msg: "home" });
    } else {
      this.setState({ msg: "login" });
    }
  };

  render() {
    if (this.state.msg === "home") {
      return (
        <React.Fragment>
          <Redirect to={"/home"} />
        </React.Fragment>
      );
    } else if (this.state.msg === "login") {
      return (
        <React.Fragment>
          <Redirect to={"/login"} />
        </React.Fragment>
      );
    }
    return (
      <React.Fragment>
        
        <div
          className="container text-center"
          style={{ maxWidth: "50%", padding: "50px", marginTop: "80px" }}
        >
          <h1 className="text-light display-4">
            <strong>Automatic License</strong>
          </h1>
          <h1 className="text-light display-4">
            <b>Plate Recognition</b>
          </h1>
          <br />
          <button
            type="button"
            style={{
              height: "80px",
              borderRadius: "5px",
              padding: "7px 0",
              margin: "10px 0",
              backgroundColor: "#F3E367",
              borderWidth: "0px"
            }}
            className="font-weight-bold btn-block text-dark display-4 btn-outline-dark"
            onClick={this.handleClick}
          >
            <span className="text-dark">TAKE A TEST DRIVE</span>
          </button>
          <br /> <br /> <br /> <br /> <br /> <br />
        </div>
        <div
          className="modal-footer "
          style={{
            backgroundColor: "black",
            borderWidth: "2px",
            borderColor: "yellow"
          }}
        >
        <div className="col-md-5">
          <span style={{ color: "yellow" }}>
            <h5 style={{ color: "yellow" }}>About Us</h5>
            <i className="fas fa-book-open" style={{ fontSize: "14px" }} />
            &nbsp;&nbsp;
            <span style={{ color: "white", fontSize: "14px" }}>
              &nbsp; License plate recognition system is a<br />
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;technology that
              uses optical character
              <br />
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;recognition on
              images to read vehicle
              <br />
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;registration
              plates.
              <br />
              <br />
            </span>
          </span>
          </div>
          <div className="col-md-5">
          <span style={{ color: "yellow" }}>
            <h5 style={{ color: "yellow" }}>Contact Us</h5>
            <i className="fas fa-map-marker-alt" style={{ fontSize: "14px" }} />
            &nbsp;&nbsp;
            <span style={{ color: "white", fontSize: "14px" }}>
              &nbsp; INFOSYS LTD Hebbal Electronic City Hootagalli
              <br />
              &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; MYSORE, Karnataka
              <br />
              <span style={{ color: "yellow" }}>
                <i className="fas fa-phone-square" style={{ fontSize: "14px" }} />
                &nbsp;&nbsp;
                <span style={{ color: "white", fontSize: "14px" }}>
                  &nbsp; 24X7 Helpline No
                  <br />
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; +91-9XXXX-XXXXX
                </span>
              </span>
              <br />
              <span style={{ color: "yellow" }}>
                <i className="fas fa-envelope" style={{ fontSize: "14px" }} />
                &nbsp;&nbsp;
                <span style={{ color: "white", fontSize: "14px" }}>
                  &nbsp; abcd.trn@infosys.com
                </span>
              </span>
            </span>
          </span>
          </div>
          <div className="col-md-2">
          <span style={{ color: "yellow" }}>
            <i className="fas fa-car" style={{ fontSize: "60px" }} />
            &nbsp;
          </span>
          <span
            className="text-light"
            style={{ fontSize: "30px", fontFamily: "Bad Script" }}
          >
            LPRS
          </span>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
Lprs = connect(mapStateToProps)(Lprs);

export default Lprs;
