import React from 'react';
import axios from "axios";
import { connect } from "react-redux"
import { Redirect } from "react-router-dom"
import { store } from "./store";
import {ProgressSpinner} from 'primereact/progressspinner';
import {Dialog} from 'primereact/dialog';
import {Growl} from 'primereact/growl';

const url = "http://localhost:2500/uploadImage/"
class ImageForm extends React.Component {
    constructor() {
        super();
        this.state = {
            file: null,
            image: "",
            details: {
                address: "",
                bloodGroup: "",
                dateOfBirth: "",
                dateOfExpiry: "",
                drivingLicenseNumber: "",
                licensePlateNumber: "",
                ownerName: "",
                sonOfDaughterOf: "",
                validity: ""
            },
            visible: false,
            progress:false,
            
        }
    }
    componentDidMount = () => {
        const action = {
            type: "Login",
            emailId: localStorage.getItem("email") ? localStorage.getItem("email") : "",
            firstName: localStorage.getItem("firstName") ? localStorage.getItem("firstName") : "",
            lastName: localStorage.getItem("lastName") ? localStorage.getItem("lastName") : "",
            password: localStorage.getItem("password") ? localStorage.getItem("password") : ""
        }
        console.log("action is ", action);
        store.dispatch(action);
    }
    submit = (event) => {
        event.preventDefault();
        this.setState({ "progress":true})

        const formData = new FormData();
        formData.append('myImage',this.state.file);
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        };

        axios.post(url, formData,config).then((response) => {
            //alert("The file is successfully received");
            var details = {
                address: response.data.address,
                bloodGroup: response.data.bloodGroup,
                dateOfBirth: response.data.dateOfBirth,
                dateOfExpiry: response.data.dateOfExpiry,
                drivingLicenseNumber: response.data.drivingLicenseNumber,
                licensePlateNumber: response.data.licensePlateNumber,
                ownerName: response.data.ownerName,
                sonOfDaughterOf: response.data.sonOfDaughterOf,
                validity: response.data.validity
            }
            
            this.setState({ "details": details,"progress":false})
            console.log(response.data)
        }).catch((error) => {
            if (error.response) {
                console.log("1st")
                this.setState({"progress":false})
                // alert(error.response.data.message);
                this.growl.show({severity: 'error', summary: 'error Message', detail: error.response.data.message});
              } else {
                this.setState({"progress":false})
                // alert(error.response.data.message);
                this.growl.show({severity: 'error', summary: 'error Message', detail: "Could not connect to server."});
                console.log(error.message)
              }
        })
    }
    imageupload = (e) => {
        this.setState({file:e.target.files[0]});
        //let x = event.target.value.split('\\')
        //this.setState({ image: x[x.length - 1], z: event.target.files[0] });
    }
    render() {
        // var path = "../images/" + this.state.image
        //console.log("in render",this.state.details)
        if (this.props.emailId.length === 0) {
            return (<Redirect to="/login" push />)
        }
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-6 offset-md-3 ">
                        <br />
                        <Growl ref={(el) => this.growl = el} style={{right:"550px"}} />
                        {this.state.progress===false?
                        <div className="card " >
                            <div className="card-header bg-dark">
                                <h3 className="text-center  text-white">
                                    <strong>UPLOAD IMAGE</strong>
                                </h3>
                            </div>
                            <div className="card-body" >
                                {this.state.details.licensePlateNumber === "" ?
                                    (<div>
                                        <form action="" >
                                            <div className="form-group">
                                            <label><strong>Choose an Image:</strong></label>&nbsp;&nbsp;&nbsp;
                                        <input id="image" name="image" type="file" accept="image/*" onChange={this.imageupload} />
                                        
                                            </div>
                                            <center><button type="submit"  className="btn  form-control bg-dark " onClick={this.submit} >
                                            <span style={{color:"white"}}><i class="fas fa-upload" ></i>&nbsp; Upload</span></button></center>
                                            
                                        </form>
                                    </div>) : (<React.Fragment>


                                        <div className="row">

                                            <div className="col-md-12 " align="center">
                                                {this.state.details.licensePlateNumber !== "" ? <img className="" src={URL.createObjectURL(this.state.file)} style={{ height: "300px", width: "300px" }} alt="not found" /> : null}
                                            </div>
                                        </div>
                                        <br/>
                                        <div className="row">
                                            <div className="col-md-12 ">
                                                {this.state.details.licensePlateNumber !== "" ? (<h3 className=" text-center" style={{ "color": "black", fontFamily: "Alegreya Sans" }}>
                                                    <strong> {this.state.details.licensePlateNumber}</strong></h3>) : null}
                                            </div>
                                        </div>
                                        
                                        <center><button type="button" className="btn btn-dark" onClick={(e) => { this.setState({ "visible": true }) }}
                                        ><span style={{color:"white"}}>Owner Details</span></button></center>
                                        {
                                        <Dialog header="Owner Details" visible={this.state.visible} style={{width: '50vw'}} modal={true} maximizable={true} onHide={() => this.setState({visible: false})}>
                                      
                                        <table  className="table table-bordered table-sm table-hover table-striped">
                                            <tbody>
                                            <tr>
                                                <th>Driving License Number</th>
                                                <td>{this.state.details.drivingLicenseNumber}</td>
                                            </tr>
                                            <tr>
                                                <th>Owner Name</th>
                                                <td>{this.state.details.ownerName}</td>
                                            </tr>
                                            <tr>
                                                <th>Validity</th>
                                                <td>{this.state.details.validity}</td>
                                            </tr>
                                            <tr>
                                                <th>Address</th>
                                                <td>{this.state.details.address}</td>
                                            </tr>
                                            {/* <tr>
                                                <th></th>
                                                <td></td>
                                            </tr> */}
                                            </tbody>
                                        </table>
                                    </Dialog>
                                    
                                    }

                                        <center> <button type="button" name="back" style={{ backgroundColor: "inherit", border: "0px  black", fontSize: "40px", color: "black" }} onClick={() => {
                                            var details = {
                                                address: "",
                                                bloodGroup: "",
                                                dateOfBirth: "",
                                                dateOfExpiry: "",
                                                drivingLicenseNumber: "",
                                                licensePlateNumber: "",
                                                ownerName: "",
                                                sonOfDaughterOf: "",
                                                validity: ""
                                            }
                                            this.setState({ "details": details })
                                            this.setState({ "showDetails": false })
                                        }

                                        }><i className="fas fa-arrow-circle-left"></i></button></center>
                                    </React.Fragment>)}
                            </div>
                        </div>:<center><ProgressSpinner style={{width: '100px', height: '100px',top:'100px'}} strokeWidth="8"  animationDuration=".5s"/></center>}

                    </div>
                </div>

            </div>
        )
    }
}

class Home extends React.Component {
    render() {
        return <ImageForm />;
    }
}
function mapStateToProps(state) {
    return {
        emailId: state.emailId,
        firstName: state.firstName,
        lastName: state.lastName,
        password: state.password,
        customerId:state.customerId
    }
}
Home = connect(mapStateToProps)(Home);
ImageForm = connect(mapStateToProps)(ImageForm);
export default Home;