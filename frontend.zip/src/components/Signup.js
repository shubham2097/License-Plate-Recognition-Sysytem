import React, { Component } from "react";
import axios from "axios";
import { Redirect } from "react-router-dom";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@material-ui/core/IconButton";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import { store } from "./store";
import { connect } from "react-redux";
// var jwt = require("jsonwebtoken");

class Signup extends Component {
  constructor() {
    super();
    this.state = {
      form: {
        firstName: "",
        lastName: "",
        emailAddress: "",
        password: "",
        confirmPassword: ""
      },
      formErrorMessage: {
        firstName: "",
        lastName: "",
        emailAddress: "",
        password: "",
        confirmPassword: ""
      },
      formValid: {
        firstName: false,
        lastName: false,
        emailAddress: false,
        password: false,
        confirmPassword: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: "",
      showPassword: false,
      showCPassword: false
    };
  }

  signupUser = () => {
    var signupObj = {
      firstName: this.state.form.firstName,
      lastName: this.state.form.lastName,
      email: this.state.form.emailAddress,
      password: this.state.form.password
    };
    var action = {
      type: "Login"
    };
    axios
      .post("http://localhost:2500/signup", signupObj)
      .then(response => {
        this.setState({
          successMessage: response.data.message,
          errorMessage: ""
        });
        var decodedObj = response.data.message;

        action.emailId = decodedObj.email;
        action.firstName = decodedObj.firstName;
        action.lastName = decodedObj.lastName;
        action.password = decodedObj.password;
        action.customerId = decodedObj.customerId;

        localStorage.setItem("email", decodedObj.email);
        localStorage.setItem("firstName", decodedObj.firstName);
        localStorage.setItem("lastName", decodedObj.lastName);
        localStorage.setItem("password", decodedObj.password);
        localStorage.setItem("customerId", decodedObj.customerId);
        store.dispatch(action);
      })
      .catch(err => {
        this.setState({
          errorMessage: err.response.data.message,
          successMessage: ""
        });
      });
  };

  handleChange = event => {
    var value = event.target.value;
    var fieldname = event.target.name;
    var form = this.state.form;

    form[fieldname] = value;

    this.setState({ form: form });
    this.validateField(fieldname, value);
  };

  validateField = (fieldName, value) => {
    var formErrorMessage = this.state.formErrorMessage;
    var formValid = this.state.formValid;

    if (fieldName === "firstName") {
      if (value === "") {
        formErrorMessage.firstName = "field required";
        formValid.firstName = false;
      } else if (value.match(/^[A-Z][a-z]{3,}$/)) {
        formErrorMessage.firstName = "";
        formValid.firstName = true;
      } else {
        formErrorMessage.firstName =
          "First letter should be capital and min 4 char long  or blank is given";
        formValid.firstName = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "lastName") {
      if (value === "") {
        formErrorMessage.lastName = "field required";
        formValid.lastName = false;
      } else if (value.match(/^[A-z]{1,}$/)) {
        formErrorMessage.lastName = "";
        formValid.lastName = true;
      }
      else {
        formErrorMessage.lastName = "Last name must be there or blank is given";
        formValid.lastName = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "emailAddress") {
      if (value === "") {
        formErrorMessage.emailAddress = "field required";
        formValid.emailAddress = false;
      } else if (
        value.match(
          /^[\w+\-.]+@(gmail|yahoo|hotmail|infosys|outlook)+\.(com|in|co.in|co.uk)$/i
        )
      ) {
        formErrorMessage.emailAddress = "";
        formValid.emailAddress = true;
      } else {
        formErrorMessage.emailAddress = "Email address must be valid";
        formValid.emailAddress = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "password") {
      var Cpass = this.state.form.confirmPassword;
      if (value === "") {
        formErrorMessage.password = "field required";
        formValid.password = false;
      } else if (value.length <= 5) {
        formErrorMessage.password = "Password must be 6 character long";
        formValid.password = false;
      } else if (Cpass) {
        if (Cpass === value) {
          formErrorMessage.confirmPassword = "";
          formValid.confirmPassword = true;
        } else {
          formErrorMessage.confirmPassword = "Password dosen't Match";
          formValid.confirmPassword = false;
        }
      } 
      else {
        formErrorMessage.password = "";
        formValid.password = true;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "confirmPassword") {
      var pass = this.state.form.password;
      if (value === "") {
        formErrorMessage.confirmPassword = "field required";
        formValid.confirmPassword = false;
      } else if (value === pass) {
        formErrorMessage.confirmPassword = "";
        formValid.confirmPassword = true;
      } else {
        formErrorMessage.confirmPassword = "Password dosen't Match";
        formValid.confirmPassword = false;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    }
    formValid.buttonActive =
      formValid.firstName &&
      formValid.lastName &&
      formValid.emailAddress &&
      formValid.password &&
      formValid.confirmPassword;

    this.setState({ formValid: formValid });
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };

  handleClickShowCPassword = () => {
    this.setState(state => ({ showCPassword: !state.showCPassword }));
  };

  handleSubmit = event => {
    event.preventDefault();
    this.signupUser();
  };

  render() {
    if (this.props.emailId.length > 0) {
      console.log("going to home");
      return <Redirect to="/login" push />;
    }

    return (
      <React.Fragment>
        <div className="Signup">
          <div className="container-fluid row">
            <div className="col-md-6 offset-md-3">
              <br />
              <div className="card" style={{ borderRadius: "20px" }}>
                <div className="card-header">
                  <h3 className="text-center">
                    <strong>Sign Up</strong>
                  </h3>
                </div>
                <div className="card-body">
                  <form onSubmit={this.handleSubmit}>
                    <div className="form-group row">
                      <label className="col-sm-1">
                        <i
                          className="fas fa-user"
                          style={{ fontSize: "25px" }}
                        />
                      </label>
                      <div className="col-sm-5">
                        <TextField
                          className="form-control"
                          type="text"
                          name="firstName"
                          onChange={this.handleChange}
                          placeholder="Enter First Name"
                        />
                        <span className="text-danger" name="firstNameError">
                          {this.state.formErrorMessage.firstName}
                        </span>
                      </div>
                      <div className="col-sm-6">
                        <TextField
                          className="form-control"
                          type="text"
                          name="lastName"
                          onChange={this.handleChange}
                          placeholder="Enter Last Name"
                        />
                        <span className="text-danger" name="lastNameError">
                          {this.state.formErrorMessage.lastName}
                        </span>
                      </div>
                    </div>

                    <div className="form-group row">
                      <label className="col-sm-1">
                        <i
                          class="fas fa-envelope"
                          style={{ fontSize: "25px" }}
                        />
                      </label>
                      <div className="col-sm-11">
                        <TextField
                          className="form-control"
                          type="email"
                          name="emailAddress"
                          onChange={this.handleChange}
                          placeholder="ex- abc@gmail.com"
                        />
                        <span className="text-danger" name="emailAddressError">
                        {this.state.formErrorMessage.emailAddress}
                      </span>
                      </div>
                      
                    </div>

                    <div className="form-group row">
                      <label className="col-sm-1">
                        <i class="fas fa-unlock" style={{ fontSize: "25px" }} />
                      </label>
                      <div className="col-sm-11">
                        <TextField
                          id="filled-adornment-password"
                          className="form-control"
                          type={this.state.showPassword ? "text" : "password"}
                          name="password"
                          value={this.state.password}
                          onChange={this.handleChange}
                          placeholder="password"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <IconButton
                                  aria-label="Toggle password visibility"
                                  onClick={this.handleClickShowPassword}
                                >
                                  {this.state.showPassword ? (
                                    <VisibilityOff />
                                  ) : (
                                    <Visibility />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            )
                          }}
                        />
                        <span className="text-danger" name="passwordError">
                          {this.state.formErrorMessage.password}
                        </span>
                      </div>
                    </div>

                    <div className="form-group row">
                      <label className="col-sm-1">
                        <i
                          class="fas fa-exclamation-triangle"
                          style={{ fontSize: "25px" }}
                        />
                      </label>
                      <div className="col-sm-11">
                        <TextField
                          className="form-control"
                          type={this.state.showCPassword ? "text" : "password"}
                          name="confirmPassword"
                          value={this.state.confirmPassword}
                          onChange={this.handleChange}
                          placeholder="Confirm Password"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <IconButton
                                  aria-label="Toggle password visibility"
                                  onClick={this.handleClickShowCPassword}
                                >
                                  {this.state.showPassword ? (
                                    <VisibilityOff />
                                  ) : (
                                    <Visibility />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            )
                          }}
                        />
                        <span
                          className="text-danger"
                          name="confirmPasswordError"
                        >
                          {this.state.formErrorMessage.confirmPassword}
                        </span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn form-control"
                      style={{ backgroundColor: "#F3E367" }}
                      disabled={!this.state.formValid.buttonActive}
                      name="lprs"
                    >
                      <strong>Be A Part Of LPRS Team</strong>
                    </button>
                    <br />
                    <span className="text-danger" name="errorMessage">
                      {this.state.errorMessage}
                    </span>
                    <br />
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
Signup = connect(mapStateToProps)(Signup);
export default Signup;
