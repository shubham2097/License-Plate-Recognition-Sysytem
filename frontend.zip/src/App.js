import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from "react-router-dom";
import { store } from "./components/store";
import { Provider } from "react-redux";
import Lprs from "./components/Lprs";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Home from "./components/Home";
import NavigationBar from "./components/NavigationBar";

class App extends Component {
  logout = () => {
    localStorage.removeItem("email");
    localStorage.removeItem("firstName");
    localStorage.removeItem("lastName");
    localStorage.removeItem("password");
    const action = {
      type: "Login",
      emailId: "",
      firstName: "",
      lastName: "",
      password: "",
      customerId: ""
    };
    store.dispatch(action);
    return <Redirect to="/lprs" push />;
  };
  render() {
    return (
      <Provider store={store}>
        <Router>
          <div>
            <NavigationBar/>
            <React.Fragment>
              <Switch>
                <Route
                  exact
                  path="/"
                  render={() => <Redirect to="/lprs" push />}
                />
                <Route path="/lprs" component={Lprs} />
                <Route path="/login" component={Login} />
                <Route path="/signup" component={Signup} />
                <Route path="/logout" component={this.logout} />
                <Route path="/home" component={Home} />
                <Route path="/" render={() => <Redirect to="/lprs" push />} />
              </Switch>
            </React.Fragment>
          </div>
        </Router>
      </Provider>
    );
  }
}

export default App;
