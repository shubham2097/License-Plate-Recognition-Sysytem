from flask import Flask, request
import json
import base64
from ImageProcessing1 import Image

app = Flask(__name__)
d={"image":""}
@app.route('/')
def index():
	return "Flask server"
 
@app.route('/postdata', methods = ['POST'])
def postdata():
    data = request.get_json()
    d["image"]=data["imageString"]
    fh = open("imageToSave.jpg", "wb")
    fh.write(base64.b64decode(d["image"]))
    fh.close()
    
    image=Image()
    image.readImage()
    image.detect_plate()
    image.segment_characters()
    image.load_model()
    image.predict_characters()
    image.get_characters_to_right_place()
    image.find()
    image.removeWrongPlateNumber()
    #image_64_decode = base64.decodestring(data["data3"]) 
    #image_result = open('test_image100.jpg', 'wb')
    #image_result.write(image_64_decode)
    # do something with this data variable that contains the data from the node server
    return json.dumps({"plateNumber":image.right_strings})

 
if __name__ == "__main__":
	app.run(port=5002,use_reloader=True)
