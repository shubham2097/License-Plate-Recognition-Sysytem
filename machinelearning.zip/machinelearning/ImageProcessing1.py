from skimage.io import imread
from skimage.filters import threshold_otsu
import matplotlib.pyplot as plt
import cv2
import imutils
from skimage import measure
from skimage.measure import regionprops
from skimage.transform import resize
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pickle

class Image:
    def __init__(self):
        self.filename='./video15.mp4'
        self.car_image=None
        self.count=0
        self.plate_objects_cordinates = []
        self.plate_like_objects = []
        self.model:None
        self.plate_string = ''
        self.rightplate_string = ''
        self.classification_result = []
        self.characters = []
        self.column_list = []
        self.plate_image_array=[]
        self.column_image_array=[]
        self.plate_array=[]
        self.right_strings=[]
        
        
    
    def video_capture(self):
        cap = cv2.VideoCapture(self.filename)
        # cap = cv2.VideoCapture(0)
        self.count = 0
        while cap.isOpened():
            ret,frame = cap.read()
            if ret == True:
                cv2.imshow('window-name',frame)
                cv2.imwrite("./output/frame%d.jpg" % self.count, frame)
                self.count = self.count + 1
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break
            else:
                break
        cap.release()
        cv2.destroyAllWindows()
        
    
    def readImage(self):
        path="./imageToSave.jpg"
        #path="./images/tt.jpg"
        self.car_image=imread(path,as_gray=True)
        self.car_image=resize(self.car_image,(600,600))
        print(self.car_image.shape)
        
    
    def read_image_from_video(self):
        self.car_image = imread("./output/frame%d.jpg"%(self.count-1), as_gray=True)
        self.car_image = imutils.rotate(self.car_image, 270)
    
    def detect_plate(self):
        gray_car_image = self.car_image * 255
        plt.imshow(self.car_image)
        #plt.savefig("C:/Users/rounak02.TRN/Desktop/lprs-front/public/carImage.jpg")
        fig, (ax1, ax2) = plt.subplots(1, 2)
        ax1.imshow(gray_car_image, cmap="gray")
        threshold_value = threshold_otsu(gray_car_image)
        binary_car_image = gray_car_image > threshold_value
        print(threshold_value)
        print(binary_car_image)
        ax2.imshow(binary_car_image, cmap="gray")
        #plt.savefig("C:/Users/rounak02.TRN/Desktop/lprs-front/public/grayScaleImage.jpg")
        plt.show()
        
        label_image = measure.label(binary_car_image)
        
        plate_dimensions = (0.03*label_image.shape[0], 0.08*label_image.shape[0], 0.15*label_image.shape[1], 0.3*label_image.shape[1])
        plate_dimensions2= (0.08*label_image.shape[0], 0.2*label_image.shape[0], 0.15*label_image.shape[1], 0.4*label_image.shape[1])
        min_height, max_height, min_width, max_width = plate_dimensions
        self.plate_objects_cordinates = []
        self.plate_like_objects = []
        
        fig, (ax1) = plt.subplots(1)
        ax1.imshow(gray_car_image, cmap="gray")
        flag =0
        # regionprops creates a list of properties of all the labelled regions
        for region in regionprops(label_image):
            #print(region)
            if region.area < 1000 :
                #if the region is so small then it's likely not a license plate
                continue
            
            
            min_row, min_col, max_row, max_col = region.bbox
        
            region_height = max_row - min_row
            region_width = max_col - min_col
            ratio=region_height/region_width
            
            if(min_row<200 or min_row>500):
                continue
            
            #if region_height >= min_height and region_height <= max_height and region_width >= min_width and region_width <= max_width and region_width > region_height:
            
            flag = 1
            self.plate_like_objects.append(binary_car_image[min_row:max_row,
                                      min_col:max_col])
            self.plate_objects_cordinates.append((min_row, min_col,
                                             max_row, max_col))
            rectBorder = patches.Rectangle((min_col, min_row), max_col - min_col, max_row - min_row, edgecolor="red",
                                           linewidth=2, fill=False)
            ax1.add_patch(rectBorder)
        
        #if(flag == 1):
        #    plt.savefig("C:/Users/rounak02.TRN/Desktop/licenseplaterecognitionsystemfrontend/public/plateRectangePatch.jpg")
        #    plt.show()
        
        
         
        #plt.savefig("C:/Users/rounak02.TRN/Desktop/lprs-front/public/plateRectangePatch.jpg")
        #if(flag==0):
        min_height, max_height, min_width, max_width = plate_dimensions2
        #plate_objects_cordinates = []
        #plate_like_objects = []
    
        fig, (ax1) = plt.subplots(1)
        ax1.imshow(gray_car_image, cmap="gray")
    
        for region in regionprops(label_image):
            if region.area < 1000:
                continue
            
            min_row, min_col, max_row, max_col = region.bbox
            region_height = max_row - min_row
            region_width = max_col - min_col
           
            #if(min_row<200 or min_row>500):
            #    continue
    
            #if region_height >= min_height and region_height <= max_height and region_width >= min_width and region_width <= max_width and region_width > region_height:
                
            self.plate_like_objects.append(binary_car_image[min_row:max_row,
                                      min_col:max_col])
            self.plate_objects_cordinates.append((min_row, min_col,
                                             max_row, max_col))
            rectBorder = patches.Rectangle((min_col, min_row), max_col - min_col, max_row - min_row, edgecolor="red",
                                           linewidth=2, fill=False)
            ax1.add_patch(rectBorder)
            
        
        plt.show()
        
    def segment_characters(self):
        
        for i in range(0,len(self.plate_like_objects)):
            license_plate = np.invert(self.plate_like_objects[i])
            license_plate=resize(license_plate,(100,300))
            labelled_plate = measure.label(license_plate)
            
            fig, ax1 = plt.subplots(1)
            ax1.imshow(license_plate, cmap="gray")
            character_dimensions = (0.20*license_plate.shape[0], 0.90*license_plate.shape[0], 0.01*license_plate.shape[1], 0.13*license_plate.shape[1])
            min_height, max_height, min_width, max_width = character_dimensions
            
            self.characters = []
            self.column_list = []
            counter=0
            for regions in regionprops(labelled_plate):
                y0, x0, y1, x1 = regions.bbox
                region_height = y1 - y0
                region_width = x1 - x0
                if(y0<10 or x0<10):
                    continue
                if region_height > min_height and region_height < max_height and region_width > min_width and region_width < max_width:
                
                    
                    counter+=1
                    roi = license_plate[y0:y1, x0:x1]
                    
                    rect_border = patches.Rectangle((x0, y0), x1 - x0, y1 - y0, edgecolor="red",
                                                   linewidth=2, fill=False)
                    ax1.add_patch(rect_border)
            
                    
                    resized_char = resize(roi, (20, 20))
                    self.characters.append(resized_char)
            
                   
                    self.column_list.append(x0)
            #plt.savefig("C:/Users/rounak02.TRN/Desktop/licenseplaterecognitionsystemfrontend/public/segmentCharacters.jpg")
            self.plate_image_array.append(self.characters)
            self.column_image_array.append(self.column_list)
            plt.show()
    
    def load_model(self):
        print("Loading model")
        filename = './finalized_model.sav'
        self.model = pickle.load(open(filename, 'rb'))
    
    def predict_characters(self):
        self.classification_result = []
        k=0
        for character in self.plate_image_array:
            for each_character in character:
                
                each_character = each_character.reshape(1, -1);
                result = self.model.predict(each_character)
                self.classification_result.append(result)
            
        

            self.plate_array.append("")
            for eachPredict in self.classification_result:
                if eachPredict[0]=="Z":
                    self.plate_array[k] += "2"
                else:
                    self.plate_array[k]+=eachPredict[0]
            self.classification_result=[]
            print('Predicted license plate',k)
            print(self.plate_array[k])
            k+=1
    
    
    def get_characters_to_right_place(self):
        
        k=0
        for column in self.column_image_array:
            column_list_copy = column[:]
            column.sort()
            self.rightplate_string=""
            for each in column:
                self.rightplate_string += self.plate_array[k][column_list_copy.index(each)]
            self.right_strings.append(self.rightplate_string)
            k+=1
        #print(self.right_strings)
    
    def remove_duplicates(self,new_strings):
        l=[]
        new_strings.sort()
        if(len(new_strings)==0):
            return l
        l.append(new_strings[0])
        for i in range(1,len(new_strings)):
            if(new_strings[i]==new_strings[i-1]):
                continue
            else:
                l.append(new_strings[i])
        return l
        
    def find(self):
        new_strings=[]
        for string in self.right_strings:
            if(string=="" or len(string)<=3):
                continue
            else:
                new_strings.append(string)
        l=self.remove_duplicates(new_strings)
        self.right_strings=l
    
    def removeWrongPlateNumber(self):
        l=[]
        for plate in self.right_strings:
            d={}
            for alphabet in plate:
                if alphabet not in d:
                    d[alphabet]=1
                else:
                    d[alphabet]+=1
            flag=1
            for key in d.keys():
                if(d[key]>4):
                    flag=0
            if(flag==1):
                l.append(plate)
        self.right_strings=l
        
def main():
    image=Image()
    image.readImage()
    #image.video_capture()
    #image.read_image_from_video()
    image.detect_plate()
    image.segment_characters()
    image.load_model()
    image.predict_characters()
    image.get_characters_to_right_place()
    image.find()
    image.removeWrongPlateNumber()
    print(image.right_strings)
    
if(__name__=="__main__"):
    main()