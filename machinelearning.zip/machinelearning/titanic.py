import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
df=pd.read_csv("train.csv")

X=df.iloc[:,2:].values
y=df.iloc[:,1].values






from sklearn.model_selection import train_test_split