from skimage.io import imread
from skimage.filters import threshold_otsu
import matplotlib.pyplot as plt
import pickle
import os
import numpy as np
from skimage.transform import resize
class NumberPrediction:
    def __init__(self):
        self.imageName="number.jpg"
        self.model=None
    
    def load_model(self):
        filename = './finalized_model.sav'
        self.model = pickle.load(open(filename, 'rb'))
    
    def predict(self):
        testing_directory="C:\\Users\\rounak02.TRN\\Desktop\\licenseplatedetectorandrecognizer\\"
        """for i in range(1,351):
            image_path = os.path.join(testing_directory,"img_"+str(i)+".jpg")
            img_details = imread(image_path, as_gray=True)
            img_details=np.invert(img_details)
            binary_image = img_details < threshold_otsu(img_details)
            binary_image=resize(binary_image,(20,20))
            binary_image=binary_image.reshape(1,-1)
            s.append(self.model.predict(binary_image))
        print(s[1])"""
        fig, (ax1, ax2) = plt.subplots(1, 2)
        
        #image_path = os.path.join(testing_directory,"img_"+str(2)+".jpg")
        image_path = os.path.join(testing_directory,"image"+".jpg")
        img_details = imread(image_path, as_grey=True)
        print(img_details.shape)
        ax1.imshow(img_details,cmap="gray")
        t=threshold_otsu(img_details)
        
        binary_image=img_details>t
        #img_details=np.invert(img_details)
        #binary_image = img_details < 
        #binary_image=resize(binary_image,(20,20))
        
        ax2.imshow(binary_image,cmap="gray")
        plt.show()
        binary_image=resize(img_details,(20,20))
        
        binary_image=binary_image.reshape(1,400)
        print(binary_image.shape)
        print(binary_image)
        print(self.model.predict(binary_image))
if(__name__=="__main__"):
    n=NumberPrediction()
    n.load_model()
    n.predict()
    