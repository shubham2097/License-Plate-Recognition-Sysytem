var Validator = {};

Validator.validateFirstName = fname => {
  let pattern = new RegExp("^[A-Z][a-z]{3,}$");
  if (!pattern.test(fname)) {
    let err = new Error(
      "First Name first letter must be capital with minimum 4 character length"
    );
    err.status = 406;
    throw err;
  }
};

Validator.validateLastName = lname => {
  // let pattern = new RegExp("^[A-Z][a-z]{1,}$");
  if (!lname.match(/^[A-z]{1,}$/)) {
    let err = new Error("Last Name must be there");
    err.status = 406;
    throw err;
  }
};

Validator.validateEmail = email => {
  if (
    !email.match(
      /^[\w+\-.]+@(gmail|yahoo|hotmail|infosys|outlook)+\.(com|in|co.in|co.uk)$/i
    )
  ) {
    let err = new Error("Email must be a valid address");
    err.status = 406;
    throw err;
  }
};

Validator.validatePassword = pass => {    
  if (pass.length <= 5) {
    let err = new Error("Password must be 6 character long");
    err.status = 406;
    throw err;
  }
};

module.exports = Validator;
