const { Schema } = require("mongoose");
var Mongoose = require("mongoose");
Mongoose.Promise = global.Promise;
var url = "mongodb://localhost:27017/Lprs_Db";

var SignupSchema = Schema(
  {
    firstName: {
      type: String,
      required : true
    },
    lastName: {
      type: String,
      required : true
    },
    email: {
      type: String,
      required : true
    },
    password:{
      type: String,
      required : true
    },
    customerId:{
      type: Number,
      required : true
    },
  },
  { collection:"Signup"}
);
var DrivingDatabaseSchema = Schema(
  {
    licensePlateNumber: {
      type: String,
      required : true
    },
    ownerName: {
      type: String,
      required : true
    },
    drivingLicenseNumber: {
      type: String,
      required : true
    },
    dateOfExpiry:{
      type: String,
      required : true
    },
    validity:{
      type: String,
      required : true
    },
    dateOfBirth:{
      type: String,
      required : true
    },
    bloodGroup:{
      type: String,
      required : true
    },
    sonOfDaughterOf:{
      type: String,
      required : true
    },
    address:{
      type: String,
      required : true
    }
  },
  { collection:"DrivingDatabase"}
);

var collection = {};

collection.getSignup = () => {
  return Mongoose.connect(url, { useNewUrlParser: true })
    .then(database => {
      return database.model("Signup", SignupSchema);
    })
    .catch(error => {
      let err = new Error("Could not connect to Database");
      err.status = 500;
      throw err;
    });
};

collection.getDrivingDatabase=()=>{
  return Mongoose.connect(url,{useNewUrlParser:true})
    .then(database=>{
      return database.model("DrivingDatabase",DrivingDatabaseSchema);
    })
    .catch(error=>{
      let err = new Error("Could not connect to Database");
      err.status = 500;
      throw err;
    })
}

module.exports = collection;
