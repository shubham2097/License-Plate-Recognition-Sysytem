class Login {
    constructor(obj) {
        this.email = obj.email;
        this.password = obj.password;
    }
}

module.exports=Login;