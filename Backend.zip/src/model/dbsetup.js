signupDocument = [
  {
    firstName: "Rounak",
    lastName: "Soni",
    email: "rounak@gmail.com",
    password: "123456",
    customerId: 1001,
  },
  {
    firstName: "Shubham",
    lastName: "Aggarwal",
    email: "shubham@yahoo.com",
    password: "123456",
    customerId: 1002,
  },
  {
    firstName: "Yash",
    lastName: "garg",
    email: "yash@infosys.com",
    password: "123456",
    customerId: 1003,
  },
  {
    firstName: "Sushant",
    lastName: "ahuja",
    email: "shushant@gmail.com",
    password: "Info@123",
    customerId: 1004,
  }
];

drivingDocument = [
  { licensePlateNumber: "DL4CCB1111", ownerName: "rounak soni", drivingLicenseNumber: "RJ78 20150013297", dateOfExpiry: "23/06/2018", validity: "22/06/2028", dateOfBirth: "01/09/1997", bloodGroup: "A+", sonOfDaughterOf: "Ram Kumar Soni", address: "27 , Rasik Mitra Lane, Bagbazar,Rajasthan" },
  { licensePlateNumber: "DL6CAB123X", ownerName: "rahul singh", drivingLicenseNumber: "DL73 20145648233", dateOfExpiry: "19/05/2014", validity: "22/06/2024", dateOfBirth: "21/05/1993", bloodGroup: "A-", sonOfDaughterOf: "ved prakash", address: "B-33/1, Gia,Delhi" },
  { licensePlateNumber: "DL7CQ1939", ownerName: "amit negi", drivingLicenseNumber: "DL73 20150113437", dateOfExpiry: "21/03/2017", validity: "22/06/2027", dateOfBirth: "16/08/1993", bloodGroup: "O+", sonOfDaughterOf: "Praveen Kumar", address: "78 , Amin Bldg, Ibrahim Rahimtoola Road, Near Jj Hospital, Mohamadali Road,New Delhi" },
  { licensePlateNumber: "KA02MJ4606", ownerName: "k l rahul", drivingLicenseNumber: "DL47 20120045269", dateOfExpiry: "12/06/2012", validity: "20/06/2022", dateOfBirth: "16/04/1982", bloodGroup: "AB+", sonOfDaughterOf: "M K Gowtham", address: "58 / Soundarya Colony, Anna Nagar West,Bengaluru,Karnataka" },
  { licensePlateNumber: "NUI6CAR", ownerName: "peter carry", drivingLicenseNumber: "AU78 20120111258", dateOfExpiry: "08/07/2014", validity: "22/06/2024", dateOfBirth: "11/03/1986", bloodGroup: "AB-", sonOfDaughterOf: "Parker Carry", address: "31  &, Frosh Chambers, Carnac Bridge, Fort Mountbatten,Australia" },
  { licensePlateNumber: "CG07CA5144", ownerName: "surya yadav", drivingLicenseNumber: "DC52 20115645269", dateOfExpiry: "13/08/2016", validity: "22/06/2026", dateOfBirth: "06/02/1989", bloodGroup: "A+", sonOfDaughterOf: "Akhilesh Yadav", address: "103 , 2nd Floor, Mahendra Chambers, Dn Road,Chattisgarh" },
  { licensePlateNumber: "MH20DV2366", ownerName: "sushant sharma", drivingLicenseNumber: "MH78 20120745264", dateOfExpiry: "23/03/2006", validity: "23/03/2026", dateOfBirth: "23/05/1993", bloodGroup: "A-", sonOfDaughterOf: "Bhanu Pratap Sharma", address: "40 ,3rd Floor, Sembudoss St, Parrys,Maharashtra" },
  { licensePlateNumber: "HR26DK8337", ownerName: "Dharmendra Pal", drivingLicenseNumber: "HR22 20160595314", dateOfExpiry: "21/01/2013", validity: "21/01/2023", dateOfBirth: "11/09/1992", bloodGroup: "B+", sonOfDaughterOf: "Ramu Pal", address: "275 , S.gandhi Marg, Princess Street,Haryana" },
  { licensePlateNumber: "CG04MF2250", ownerName: "Rajat Sharma", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "12/03/2016", validity: "12/03/2026", dateOfBirth: "11/09/1991", bloodGroup: "AB+", sonOfDaughterOf: "Dev Sharma", address: "68  Joshi Bldg, B Mohammadali Road, Chattisgarh" },
  { licensePlateNumber: "TS08FM8888", ownerName: "abhishek kumar", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "16/05/2014", validity: "16/05/2024", dateOfBirth: "21/08/1996", bloodGroup: "B-", sonOfDaughterOf: "Rahul kumar", address: "Shop No 318, A, A-z Indl Estate, G K Road, Telangana" },
  { licensePlateNumber: "TN06S5656", ownerName: "satish kaushik", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "23/06/2009", validity: "23/06/2019", dateOfBirth: "01/05/1982", bloodGroup: "O+", sonOfDaughterOf: "Mohan kaushik", address: "Off-5, K-7, 5 Pioneer Heritage Residency Gr Floor, K-7 S.v. Road, Near Sane Guruji School , Subway R,Tamil Nadu" },
  { licensePlateNumber: "KA05MT8654", ownerName: "rahul chauhan", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "08/05/2011", validity: "08/05/2021", dateOfBirth: "13/03/1983", bloodGroup: "B+", sonOfDaughterOf: "karna chauhan", address: "434 , Dalmal Tower, Nr Mantralaya, Nariman Point,Karnataka" },
  { licensePlateNumber: "MH46AU2491", ownerName: "paras tiwari", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "09/03/2017", validity: "09/03/2027", dateOfBirth: "18/08/1988", bloodGroup: "A+", sonOfDaughterOf: "R C Tiwari", address: "779 , Adarsh Nagar, New Link Road, Near Lotus Lane Next To Pushpa Lan, Maharastra" },
  { licensePlateNumber: "KL65K7111", ownerName: "abhijeet rathore", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "23/09/2018", validity: "23/09/2028", dateOfBirth: "23/06/1989", bloodGroup: "AB-", sonOfDaughterOf: "nikhil rathore", address: "154 , 2nd Floor, Musa Kiledar Street, Jacob Circle, Kerela" },
  { licensePlateNumber: "KA04MA9018", ownerName: "naman sati", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "01/02/2019", validity: "01/02/2029", dateOfBirth: "24/12/1994", bloodGroup: "A-", sonOfDaughterOf: "naresh sati", address: "B-43, Todi Est., Sunmill Compound, Opp. Big Bazar, Karnataka" },
  { licensePlateNumber: "MH14CS7483", ownerName: "karan singh", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "21/05/2016", validity: "21/05/2026", dateOfBirth: "22/11/1995", bloodGroup: "AB-", sonOfDaughterOf: "mridul singh", address: "Bhagoji Bhandar Chawl, S V Rd, Dewan Centre, Jogeshwari, Maharastra" },
  { licensePlateNumber: "DL4CCB1111", ownerName: "shailja negi", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "23/06/2016", validity: "23/06/2026", dateOfBirth: "19/09/1987", bloodGroup: "A+", sonOfDaughterOf: "vineet negi", address: "G 10 Nav Samaj Soc., Gujarathi Soc Rd., Vile Parle, New Delhi" },
  { licensePlateNumber: "TN07AJ5500", ownerName: "vedu murriappa", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "05/04/2012", validity: "05/04/2022", dateOfBirth: "17/07/1983", bloodGroup: "B+", sonOfDaughterOf: "M C Murriappa", address: "44  B Wing, , Prem Nagar, S B P Road, Tamil Nadu" },
  { licensePlateNumber: "MH12DE1433", ownerName: "rakesh kadam", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "16/02/2011", validity: "16/02/2021", dateOfBirth: "13/03/1986", bloodGroup: "AB+", sonOfDaughterOf: "Vinod Kadam", address: "16 rd Floor, Century Bhavan, Dr Annie Besant Road, Worli,Mumbai , Maharastra" },
  { licensePlateNumber: "DL8CX4850", ownerName: "anuj chaudhary", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "18/03/2015", validity: "18/03/2025", dateOfBirth: "11/10/1989", bloodGroup: "B+", sonOfDaughterOf: "Anil Chaudhary", address: "Shreeji House , Laheripura New Road, Laheripura New Road,New Delhi" },
  { licensePlateNumber: "MH20EE7598", ownerName: "sivaji mosai", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "10/08/2014", validity: "10/08/2024", dateOfBirth: "09/06/1994", bloodGroup: "B-", sonOfDaughterOf: "dorji mosai", address: "64  d Floor, Navyug House,  Old Hanuman Lane, Near Indrabhuvan Hotel, Kalbadevi,Maharastra" },
  { licensePlateNumber: "TS07FX3534", ownerName: "m k tiruchi", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "09/09/2018", validity: "09/09/2028", dateOfBirth: "03/01/1993", bloodGroup: "B-", sonOfDaughterOf: "p c tiruchi", address: "131 -a, B Wing, Mittal Court, Nariman Point, Telangana" },
  { licensePlateNumber: "MH01AV8866", ownerName: "nalin sharma", drivingLicenseNumber: "DL78 20150013297", dateOfExpiry: "18/02/2017", validity: "18/02/2027", dateOfBirth: "12/02/1997", bloodGroup: "A-", sonOfDaughterOf: "prakash raj sharma", address: "First Flr, 2/b,shop No.4, Rawal Pindiwala Bldg, Tribuvan Road, Girgaon,Maharastra" }
]
var collection = require("../utilities/connections");

exports.setupDb = () => {
  return collection.getSignup().then(SignupCollection => {
    return SignupCollection.deleteMany().then(data => {
      return SignupCollection.insertMany(signupDocument).then(signupdata => {
        if (signupdata) {
          console.log("Sign up Insertion Successfull");
          return collection.getDrivingDatabase().then(drivingDatabaseCollection => {
            return drivingDatabaseCollection.deleteMany().then(data => {
              return drivingDatabaseCollection.insertMany(drivingDocument).then(drivingdata => {
                if (drivingdata) {
                  console.log("driving database insertion successfull");
                } else {
                  console.log("driving database insertion failed");
                  throw new Error("driving database insertion failed");
                }
              })
            })
          })
        } else {
          throw new Error("Sign up Insertion failed");
        }
      });
    });
  });
};
