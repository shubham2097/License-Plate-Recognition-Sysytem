var express = require("express");
var routing = express.Router();
var create = require("../model/dbsetup");
var Login = require("../model/Login");
var Signup = require("../model/Signup");
var service = require("../service/user");
var jwt = require('jsonwebtoken');
const image2base64 = require('image-to-base64');
const request=require("request-promise");   
const path = require("path");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: "./public/uploads/",
  filename: function(req, file, cb){
     cb(null,"IMAGE-" + Date.now() + path.extname(file.originalname));
  }
}); 
const upload = multer({
  storage: storage,
  limits:{fileSize: 1000000},
}).single("myImage");

routing.post("/upload",(req, res, next) => {
  upload(req, res, (err) => {
    console.log("Request ---", req.body);
    console.log("Request file ---", req.file);//Here you get file.
    /*Now do where ever you want to do*/
    if(!err)
       return res.send(200).end();
 });
}); 


routing.get("/setupDb", (req, res, next) => {
  create
    .setupDb()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      next(err);
    });
});
routing.post("/uploadImage",(req,res,next)=>{
  //const obj=req.body;
  //const imageName=obj.image;
  //console.log(imageName)
  upload(req, res, (err) => {
    console.log("Request ---", req.body);
    console.log("Request file ---", req.file);//Here you get file.
    /*Now do where ever you want to do*/
    const path="./public/uploads/"+req.file.filename
  image2base64(path).then(async (response)=>{   
      var data = { 
          imageString:response
      }
      var options = {
          method: 'POST',
          uri: 'http://localhost:5002/postdata',
          body: data,
          json: true // Automatically stringifies the body to JSON
      };
      var sendrequest = await request(options)
      .then(function (returndata) { 
          console.log("here in promise")
          console.log(returndata["plateNumber"])
          if(returndata["plateNumber"].length==0){
            let err = new Error("Unable to predict the license plate");
            err.status=500;
            throw err;
          }
          service.findCorrectPlate(returndata)
            .then((response)=>{
              console.log(response)
             if(response!=null){
                //let ans={"plateNumber":response}
                res.send(response)
             }
            
            })
          
        })
      .catch(function (err) {
          console.log(err);
          next(err)
      });
  }).catch((error)=>{
      console.log(error);
      next(error);
  })




    // if(!err)
    //    return res.send(200).end();
 });
  
})

routing.post("/signup", function(req, res, next) {
  const UserObj = new Signup(req.body);
  service
    .signupUser(UserObj)
    .then(cust => {
      var tokenObj = jwt.sign({customerId:cust.customerId,
        firstName:cust.firstName,
        lastName:cust.lastName,
        email:cust.email,
        password:cust.password },'shhhhh',{ expiresIn: '1h' });

        // cust ko tokenObj convert
      res.json({ message: cust});
    })
    .catch(err => {
      next(err);
    });
});

routing.post("/login", function(req, res, next) {
  const loginObj = new Login(req.body);
  service
    .loginUser(loginObj)
    .then(cust=> {
     
      var tokenObj = jwt.sign({customerId:cust.customerId,
                                firstName:cust.firstName,
                                lastName:cust.lastName,
                                email:cust.email,
                                password:cust.password },'shhhhh',{ expiresIn: '6000ms' });    
      res.json({ message:tokenObj});
    })
    .catch(err => {
      next(err);
    });
});

routing.put("/edit", function(req, res, next) {
  const UserObj = new Signup(req.body);
  service
    .editUser(UserObj)
    .then(obj => {
     
      res.json({ message: obj});
    })
    .catch(err => {
      next(err);
    });
});

module.exports = routing;
