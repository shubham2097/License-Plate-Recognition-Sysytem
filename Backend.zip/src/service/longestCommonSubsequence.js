var longestCommonSubsequence=(m,n)=>{
    var L = []
    for(let i=0;i<=m.length;i++){
        let result=[]
        for(let j=0;j<=n.length;j++){
            result.push(0);

        }
        L.push(result);
    }
    
    for (let i=0; i<=m.length; i++) 
    { 
      for (let j=0; j<=m.length; j++) 
      { 
        if (i == 0 || j == 0) 
            L[i][j] = 0; 
        else if (m[i-1] == n[j-1]) 
            L[i][j] = L[i-1][j-1] + 1; 
        else
            L[i][j] = max(L[i-1][j], L[i][j-1]); 
      } 
    } 
    console.log(L)
  return L[m.length][n.length];
}
var max=(x,y)=>x>y?x:y;

console.log(longestCommonSubsequence("ronak","rnak"))